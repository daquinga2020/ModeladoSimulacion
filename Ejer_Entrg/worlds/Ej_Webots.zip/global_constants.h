
#ifndef _GLOBAL_CONSTANTS_H
#define _GLOBAL_CONSTANTS_H


#define PI 3.14
#define TIME_STEP 32

enum {LEFT, RIGHT};

#endif