
#ifndef _DISTANCESENSORS_MODULE_H
#define _DISTANCESENSORS_MODULE_H

#include "global_constants.h"

void distance_sensors_init(void);

int distance_sensors_detect_obstacle(void);


#endif